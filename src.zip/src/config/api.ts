// ── API config ──────────────────────────────────────────
// เปลี่ยนเป็น IP จริงของเครื่องที่รัน backend เมื่อ deploy บนอุปกรณ์จริง
// Android Emulator: 10.0.2.2 | iOS Simulator: localhost | อุปกรณ์จริง: IP LAN เช่น 192.168.1.x

export const API_BASE_URL = 'http://10.0.2.2:3001/api/app';
export const DEMO_USER_ID = 1;
