import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, TextInput,
  FlatList, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { ArrowLeft, Send, Wifi, WifiOff } from 'lucide-react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/fonts';
import { useMqtt } from '../hooks/useMqtt';
import { DEMO_USER_ID } from '../config/api';

const BROKER_URL = 'wss://broker.emqx.io:8084/mqtt';
// หัวข้อ MQTT แยกต่อ conversation → sabaidimai/dm/{conversationId}
// ถ้ายังไม่มี conv id ใช้ sabaidimai/dm/u{smallId}_u{largeId}

function buildTopic(convId: number | null, myId: number, friendId: number): string {
  if (convId) return `sabaidimai/dm/${convId}`;
  const [a, b] = myId < friendId ? [myId, friendId] : [friendId, myId];
  return `sabaidimai/dm/u${a}_u${b}`;
}

export function DirectChatScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const { conversationId, friendName, friendId } = route.params ?? {};

  const myId = DEMO_USER_ID;
  const topic = buildTopic(conversationId, myId, friendId);

  const { status, messages, sendMessage } = useMqtt({
    brokerUrl: BROKER_URL,
    topic,
    username: `user_${myId}`,
    avatarColor: colors.primary,
  });

  const [text, setText] = useState('');
  const flatRef = useRef<FlatList>(null);

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [messages]);

  const handleSend = () => {
    if (!text.trim()) return;
    sendMessage(text.trim());
    setText('');
  };

  const StatusIcon = status === 'connected' ? Wifi : WifiOff;
  const statusColor = status === 'connected' ? colors.primary : colors.warning;

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
    >
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <ArrowLeft size={20} color={colors.mutedForeground} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerName}>{friendName || 'แชต'}</Text>
          <View style={styles.statusRow}>
            <StatusIcon size={11} color={statusColor} />
            <Text style={[styles.statusText, { color: statusColor }]}>
              {status === 'connected' ? 'ออนไลน์' : status === 'connecting' ? 'กำลังเชื่อมต่อ...' : 'ออฟไลน์'}
            </Text>
          </View>
        </View>
      </View>

      {/* Messages */}
      {status === 'connecting' && messages.length === 0 ? (
        <View style={styles.loadingBox}>
          <ActivityIndicator color={colors.primary} />
          <Text style={styles.loadingText}>กำลังเชื่อมต่อ MQTT...</Text>
        </View>
      ) : (
        <FlatList
          ref={flatRef}
          data={messages}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.msgList}
          renderItem={({ item, index }) => {
            const prevMsg = messages[index - 1];
            const showSender = !item.isOwn && (!prevMsg || prevMsg.sender !== item.sender);
            return (
              <View style={[styles.msgWrap, item.isOwn ? styles.msgWrapOwn : styles.msgWrapOther]}>
                {!item.isOwn && (
                  <View style={[styles.msgAvatar, { backgroundColor: item.avatarColor + '22' }]}>
                    <Text style={[styles.msgAvatarText, { color: item.avatarColor }]}>{item.senderInitials}</Text>
                  </View>
                )}
                <View style={styles.msgContent}>
                  {showSender && <Text style={styles.msgSenderName}>{item.sender}</Text>}
                  <View style={[styles.bubble, item.isOwn ? styles.bubbleOwn : styles.bubbleOther]}>
                    <Text style={[styles.bubbleText, item.isOwn && styles.bubbleTextOwn]}>{item.content}</Text>
                  </View>
                  <Text style={[styles.msgTime, item.isOwn && styles.msgTimeOwn]}>{item.timestamp}</Text>
                </View>
              </View>
            );
          }}
          ListEmptyComponent={
            <View style={styles.emptyChat}>
              <Text style={styles.emptyChatText}>เริ่มต้นการสนทนากับ {friendName} ได้เลย</Text>
            </View>
          }
        />
      )}

      {/* Input */}
      <View style={styles.inputBar}>
        <TextInput
          style={styles.input}
          value={text}
          onChangeText={setText}
          placeholder="พิมพ์ข้อความ..."
          placeholderTextColor={colors.mutedForeground}
          multiline
          maxLength={500}
          onSubmitEditing={handleSend}
          blurOnSubmit={false}
        />
        <TouchableOpacity
          style={[styles.sendBtn, !text.trim() && styles.sendBtnDisabled]}
          onPress={handleSend}
          disabled={!text.trim()}
        >
          <Send size={18} color={text.trim() ? colors.white : colors.mutedForeground} />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingHorizontal: 20, paddingTop: 20, paddingBottom: 14,
    backgroundColor: colors.card, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: colors.muted, alignItems: 'center', justifyContent: 'center',
  },
  headerCenter: { flex: 1 },
  headerName: { fontSize: 16, color: colors.foreground, fontFamily: fonts.semiBold },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 },
  statusText: { fontSize: 11, fontFamily: fonts.regular },
  loadingBox: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  loadingText: { fontSize: 13, color: colors.mutedForeground, fontFamily: fonts.regular },
  msgList: { padding: 16, gap: 6 },
  msgWrap: { flexDirection: 'row', gap: 8, maxWidth: '80%' },
  msgWrapOwn: { alignSelf: 'flex-end', flexDirection: 'row-reverse' },
  msgWrapOther: { alignSelf: 'flex-start' },
  msgAvatar: {
    width: 30, height: 30, borderRadius: 15,
    alignItems: 'center', justifyContent: 'center', alignSelf: 'flex-end',
  },
  msgAvatarText: { fontSize: 11, fontFamily: fonts.semiBold },
  msgContent: { gap: 2 },
  msgSenderName: { fontSize: 11, color: colors.mutedForeground, fontFamily: fonts.regular, marginLeft: 2 },
  bubble: {
    borderRadius: 16, paddingHorizontal: 14, paddingVertical: 9,
    maxWidth: 260,
  },
  bubbleOther: {
    backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
    borderBottomLeftRadius: 4,
  },
  bubbleOwn: { backgroundColor: colors.primary, borderBottomRightRadius: 4 },
  bubbleText: { fontSize: 14, color: colors.foreground, fontFamily: fonts.regular, lineHeight: 20 },
  bubbleTextOwn: { color: colors.white },
  msgTime: { fontSize: 10, color: colors.mutedForeground, fontFamily: fonts.regular, marginLeft: 4 },
  msgTimeOwn: { textAlign: 'right', marginRight: 4 },
  emptyChat: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 80 },
  emptyChatText: { fontSize: 13, color: colors.mutedForeground, fontFamily: fonts.regular, textAlign: 'center' },
  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end', gap: 8,
    paddingHorizontal: 16, paddingVertical: 12,
    backgroundColor: colors.card, borderTopWidth: 1, borderTopColor: colors.border,
  },
  input: {
    flex: 1, backgroundColor: colors.inputBackground, borderRadius: 20,
    paddingHorizontal: 16, paddingVertical: 10, fontSize: 14,
    color: colors.foreground, fontFamily: fonts.regular, maxHeight: 100,
  },
  sendBtn: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center',
  },
  sendBtnDisabled: { backgroundColor: colors.muted },
});
