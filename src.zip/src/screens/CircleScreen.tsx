import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  Modal, TextInput, Alert,
} from 'react-native';
import { Phone, UserPlus, Trash2, Edit2, X, Check } from 'lucide-react-native';
import { useApp } from '../context/AppContext';
import { colors } from '../theme/colors';
import { fonts } from '../theme/fonts';

interface BackupContact {
  id: string;
  name: string;
  phone: string;
  relation: string;
}

export function CircleScreen() {
  const { state, updateSettings } = useApp();
  const [backupContacts, setBackupContacts] = useState<BackupContact[]>(
    (state.settings as any).backupContacts || []
  );
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<BackupContact | null>(null);
  const [form, setForm] = useState({ name: '', phone: '', relation: '' });

  const openAdd = () => {
    setEditing(null);
    setForm({ name: '', phone: '', relation: '' });
    setShowModal(true);
  };

  const openEdit = (contact: BackupContact) => {
    setEditing(contact);
    setForm({ name: contact.name, phone: contact.phone, relation: contact.relation });
    setShowModal(true);
  };

  const saveContact = () => {
    if (!form.name.trim() || !form.phone.trim()) {
      Alert.alert('กรุณากรอกชื่อและเบอร์โทร');
      return;
    }
    let updated: BackupContact[];
    if (editing) {
      updated = backupContacts.map(c => c.id === editing.id ? { ...c, ...form } : c);
    } else {
      updated = [...backupContacts, { id: Date.now().toString(), ...form }];
    }
    setBackupContacts(updated);
    updateSettings({ ...(state.settings as any), backupContacts: updated });
    setShowModal(false);
  };

  const deleteContact = (id: string) => {
    Alert.alert('ลบผู้ติดต่อ', 'ต้องการลบผู้ติดต่อสำรองนี้ใช่ไหม?', [
      { text: 'ยกเลิก', style: 'cancel' },
      {
        text: 'ลบ', style: 'destructive',
        onPress: () => {
          const updated = backupContacts.filter(c => c.id !== id);
          setBackupContacts(updated);
          updateSettings({ ...(state.settings as any), backupContacts: updated });
        },
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <ScrollView style={styles.scroll} contentContainerStyle={styles.inner}>
        <View style={styles.headerBlock}>
          <Text style={styles.title}>เบอร์ฉุกเฉินของคุณ</Text>
          <Text style={styles.subtitle}>ผู้คนที่ห่วงใยและพร้อมช่วยเหลือ</Text>
        </View>

        {/* Primary contact */}
        <Text style={styles.sectionLabel}>ผู้ติดต่อหลัก</Text>
        <View style={styles.contactCard}>
          <View style={styles.contactAvatar}>
            <Text style={styles.contactAvatarText}>
              {state.settings.primaryContact?.name.charAt(0) || 'P'}
            </Text>
          </View>
          <View style={styles.contactInfo}>
            <Text style={styles.contactName}>
              {state.settings.primaryContact?.name || 'ยังไม่ได้ตั้งค่า'}
            </Text>
            <View style={styles.phoneRow}>
              <Phone size={13} color={colors.mutedForeground} />
              <Text style={styles.phoneText}>
                {state.settings.primaryContact?.phone || 'ไม่มีเบอร์โทร'}
              </Text>
            </View>
          </View>
          <View style={styles.primaryBadge}>
            <Text style={styles.primaryBadgeText}>หลัก</Text>
          </View>
        </View>

        {/* Backup contacts */}
        <View style={styles.sectionRow}>
          <Text style={styles.sectionLabel}>ผู้ติดต่อสำรอง</Text>
          <TouchableOpacity style={styles.addSmallBtn} onPress={openAdd}>
            <UserPlus size={14} color={colors.primary} />
            <Text style={styles.addSmallBtnText}>เพิ่ม</Text>
          </TouchableOpacity>
        </View>

        {backupContacts.length === 0 ? (
          <TouchableOpacity style={styles.addCard} onPress={openAdd}>
            <View style={styles.addIcon}>
              <UserPlus size={24} color={colors.mutedForeground} />
            </View>
            <Text style={styles.addTitle}>เพิ่มผู้ติดต่อสำรอง</Text>
            <Text style={styles.addDesc}>
              จะได้รับแจ้งเตือนเมื่อผู้ติดต่อหลักตอบกลับไม่ได้
            </Text>
          </TouchableOpacity>
        ) : (
          backupContacts.map(contact => (
            <View key={contact.id} style={styles.backupCard}>
              <View style={[styles.contactAvatar, styles.backupAvatar]}>
                <Text style={[styles.contactAvatarText, styles.backupAvatarText]}>
                  {contact.name.charAt(0)}
                </Text>
              </View>
              <View style={styles.contactInfo}>
                <Text style={styles.contactName}>{contact.name}</Text>
                <View style={styles.phoneRow}>
                  <Phone size={12} color={colors.mutedForeground} />
                  <Text style={styles.phoneText}>{contact.phone}</Text>
                  {contact.relation ? (
                    <View style={styles.relationBadge}>
                      <Text style={styles.relationText}>{contact.relation}</Text>
                    </View>
                  ) : null}
                </View>
              </View>
              <View style={styles.cardActions}>
                <TouchableOpacity style={styles.iconBtn} onPress={() => openEdit(contact)}>
                  <Edit2 size={15} color={colors.mutedForeground} />
                </TouchableOpacity>
                <TouchableOpacity style={styles.iconBtn} onPress={() => deleteContact(contact.id)}>
                  <Trash2 size={15} color={colors.destructive} />
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}

        {backupContacts.length > 0 && (
          <TouchableOpacity style={styles.addMoreBtn} onPress={openAdd}>
            <UserPlus size={15} color={colors.primary} />
            <Text style={styles.addMoreText}>เพิ่มผู้ติดต่อสำรองเพิ่มเติม</Text>
          </TouchableOpacity>
        )}

        {/* Info box */}
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>วิธีการทำงาน</Text>
          {[
            'ผู้ติดต่อหลักจะได้รับแจ้งเตือนก่อนถ้าคุณไม่เช็กอิน',
            'ผู้ติดต่อสำรองจะถูกติดต่อเฉพาะเมื่อจำเป็น',
            'ไม่มีใครสามารถติดตามตำแหน่งคุณได้',
          ].map((txt, i) => (
            <View key={i} style={styles.infoItem}>
              <View style={styles.bullet} />
              <Text style={styles.infoItemText}>{txt}</Text>
            </View>
          ))}
        </View>
      </ScrollView>

      {/* Add/Edit modal */}
      <Modal visible={showModal} transparent animationType="slide" onRequestClose={() => setShowModal(false)}>
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editing ? 'แก้ไขผู้ติดต่อ' : 'เพิ่มผู้ติดต่อสำรอง'}</Text>
              <TouchableOpacity onPress={() => setShowModal(false)}>
                <X size={20} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>

            <Text style={styles.fieldLabel}>ชื่อ-นามสกุล *</Text>
            <TextInput
              style={styles.fieldInput}
              value={form.name}
              onChangeText={v => setForm(p => ({ ...p, name: v }))}
              placeholder="เช่น คุณสมใจ ใจดี"
              placeholderTextColor={colors.mutedForeground}
            />

            <Text style={styles.fieldLabel}>เบอร์โทรศัพท์ *</Text>
            <TextInput
              style={styles.fieldInput}
              value={form.phone}
              onChangeText={v => setForm(p => ({ ...p, phone: v }))}
              placeholder="08x-xxx-xxxx"
              placeholderTextColor={colors.mutedForeground}
              keyboardType="phone-pad"
            />

            <Text style={styles.fieldLabel}>ความสัมพันธ์</Text>
            <TextInput
              style={styles.fieldInput}
              value={form.relation}
              onChangeText={v => setForm(p => ({ ...p, relation: v }))}
              placeholder="เช่น ลูก, หลาน, เพื่อนบ้าน"
              placeholderTextColor={colors.mutedForeground}
            />

            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setShowModal(false)}>
                <Text style={styles.cancelText}>ยกเลิก</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={saveContact}>
                <Check size={15} color={colors.white} />
                <Text style={styles.saveBtnText}>{editing ? 'บันทึก' : 'เพิ่ม'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { flex: 1 },
  inner: { padding: 24, maxWidth: 448, alignSelf: 'center', width: '100%', paddingBottom: 40 },
  headerBlock: { paddingTop: 12, paddingBottom: 28 },
  title: { fontSize: 22, color: colors.foreground, fontFamily: fonts.semiBold },
  subtitle: { fontSize: 13, color: colors.mutedForeground, marginTop: 4, fontFamily: fonts.regular },
  sectionRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  sectionLabel: { fontSize: 11, color: colors.mutedForeground, fontFamily: fonts.medium, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 },
  contactCard: {
    backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
    borderRadius: 16, padding: 18, flexDirection: 'row',
    alignItems: 'center', gap: 14, marginBottom: 24,
  },
  contactAvatar: {
    width: 46, height: 46, borderRadius: 23,
    backgroundColor: colors.primary10, alignItems: 'center', justifyContent: 'center',
  },
  contactAvatarText: { fontSize: 18, color: colors.primary, fontFamily: fonts.semiBold },
  contactInfo: { flex: 1 },
  contactName: { fontSize: 15, color: colors.foreground, fontFamily: fonts.medium },
  phoneRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 4 },
  phoneText: { fontSize: 13, color: colors.mutedForeground, fontFamily: fonts.regular },
  primaryBadge: {
    backgroundColor: colors.primary10, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20,
  },
  primaryBadgeText: { fontSize: 11, color: colors.primary, fontFamily: fonts.medium },
  backupCard: {
    backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border,
    borderRadius: 14, padding: 14, flexDirection: 'row',
    alignItems: 'center', gap: 12, marginBottom: 10,
  },
  backupAvatar: { backgroundColor: colors.safe20, width: 40, height: 40, borderRadius: 20 },
  backupAvatarText: { color: colors.safe, fontSize: 15 },
  cardActions: { flexDirection: 'row', gap: 4 },
  iconBtn: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: colors.muted, alignItems: 'center', justifyContent: 'center',
  },
  relationBadge: {
    backgroundColor: colors.safe10, paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8,
  },
  relationText: { fontSize: 10, color: colors.safe, fontFamily: fonts.regular },
  addCard: {
    backgroundColor: colors.card, borderWidth: 2, borderStyle: 'dashed',
    borderColor: colors.border, borderRadius: 16, padding: 28,
    alignItems: 'center', marginBottom: 16,
  },
  addIcon: {
    width: 48, height: 48, borderRadius: 24,
    backgroundColor: colors.muted, alignItems: 'center', justifyContent: 'center', marginBottom: 10,
  },
  addTitle: { fontSize: 14, color: colors.foreground, marginBottom: 4, fontFamily: fonts.medium },
  addDesc: { fontSize: 12, color: colors.mutedForeground, textAlign: 'center', fontFamily: fonts.regular, lineHeight: 18 },
  addSmallBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  addSmallBtnText: { fontSize: 13, color: colors.primary, fontFamily: fonts.medium },
  addMoreBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, padding: 12, borderRadius: 12, borderWidth: 1,
    borderColor: colors.primary + '44', backgroundColor: colors.primary5,
    marginBottom: 20,
  },
  addMoreText: { fontSize: 13, color: colors.primary, fontFamily: fonts.medium },
  infoBox: {
    backgroundColor: colors.primary5, borderWidth: 1,
    borderColor: colors.primary20, borderRadius: 12, padding: 16,
  },
  infoTitle: { fontSize: 13, color: colors.foreground, marginBottom: 10, fontFamily: fonts.medium },
  infoItem: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginBottom: 8 },
  bullet: { width: 5, height: 5, borderRadius: 3, backgroundColor: colors.primary, marginTop: 6 },
  infoItemText: { flex: 1, fontSize: 12, color: colors.mutedForeground, fontFamily: fonts.regular, lineHeight: 18 },
  // Modal
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'flex-end' },
  modal: {
    backgroundColor: colors.card, borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 24, paddingBottom: 40,
  },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  modalTitle: { fontSize: 17, color: colors.foreground, fontFamily: fonts.semiBold },
  fieldLabel: { fontSize: 12, color: colors.mutedForeground, fontFamily: fonts.medium, marginBottom: 6 },
  fieldInput: {
    backgroundColor: colors.inputBackground, borderWidth: 1, borderColor: colors.border,
    borderRadius: 10, paddingHorizontal: 14, paddingVertical: 11,
    fontSize: 14, color: colors.foreground, fontFamily: fonts.regular, marginBottom: 14,
  },
  modalBtns: { flexDirection: 'row', gap: 10, marginTop: 4 },
  cancelBtn: {
    flex: 1, paddingVertical: 13, borderRadius: 12,
    borderWidth: 1, borderColor: colors.border, alignItems: 'center',
  },
  cancelText: { fontSize: 14, color: colors.mutedForeground, fontFamily: fonts.regular },
  saveBtn: {
    flex: 1, backgroundColor: colors.primary, paddingVertical: 13,
    borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
  },
  saveBtnText: { fontSize: 14, color: colors.white, fontFamily: fonts.medium },
});
