import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet,
  ScrollView, TextInput, KeyboardAvoidingView,
  Platform, ActivityIndicator,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { ArrowLeft, Send, Wifi, WifiOff } from 'lucide-react-native';
import { colors } from '../theme/colors';
import { fonts } from '../theme/fonts';
import { useMqtt } from '../hooks/useMqtt';

const BROKER_URL = 'wss://broker.emqx.io:8084/mqtt';
const TOPIC_PREFIX = 'sabaidimai/chat';

function AskUsernameModal({ onConfirm }: { onConfirm: (name: string) => void }) {
  const [name, setName] = useState('');
  return (
    <View style={modal.overlay}>
      <View style={modal.box}>
        <Text style={modal.title}>ชื่อที่ใช้ในห้องแชท</Text>
        <Text style={modal.subtitle}>ชื่อนี้จะแสดงให้ผู้อื่นในห้องเห็น (ไม่ระบุตัวตน)</Text>
        <TextInput
          style={modal.input}
          value={name}
          onChangeText={setName}
          placeholder="เช่น ทะเล, น้องแมว..."
          placeholderTextColor={colors.mutedForeground}
          maxLength={20}
          autoFocus
        />
        <TouchableOpacity
          style={[modal.btn, !name.trim() && modal.btnDisabled]}
          onPress={() => name.trim() && onConfirm(name.trim())}
          disabled={!name.trim()}
        >
          <Text style={modal.btnText}>เข้าห้อง</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const modal = StyleSheet.create({
  overlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.45)', alignItems: 'center', justifyContent: 'center', zIndex: 100 },
  box: { backgroundColor: colors.card, borderRadius: 20, padding: 28, width: '85%', maxWidth: 360 },
  title: { fontSize: 18, color: colors.foreground, fontFamily: fonts.medium, marginBottom: 6 },
  subtitle: { fontSize: 13, color: colors.mutedForeground, fontFamily: fonts.regular, marginBottom: 20 },
  input: { backgroundColor: colors.inputBackground, borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, fontSize: 15, color: colors.foreground, fontFamily: fonts.regular, marginBottom: 16 },
  btn: { backgroundColor: colors.primary, borderRadius: 12, paddingVertical: 14, alignItems: 'center' },
  btnDisabled: { opacity: 0.4 },
  btnText: { color: colors.white, fontSize: 15, fontFamily: fonts.medium },
});

function StatusBadge({ status }: { status: string }) {
  const isConnected = status === 'connected';
  const isConnecting = status === 'connecting';
  return (
    <View style={badge.row}>
      {isConnecting
        ? <ActivityIndicator size={10} color={colors.warning} style={{ marginRight: 4 }} />
        : isConnected
          ? <Wifi size={12} color={colors.primary} style={{ marginRight: 4 }} />
          : <WifiOff size={12} color={colors.destructive} style={{ marginRight: 4 }} />
      }
      <Text style={[badge.text, { color: isConnected ? colors.primary : isConnecting ? colors.warning : colors.destructive }]}>
        {isConnected ? 'ออนไลน์' : isConnecting ? 'กำลังเชื่อมต่อ...' : 'ออฟไลน์'}
      </Text>
    </View>
  );
}

const badge = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center' },
  text: { fontSize: 11, fontFamily: fonts.regular },
});

export function ChatRoomScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const { roomId = 'general', roomName = 'ทั่วไป', roomIcon = '💬' } = route.params || {};

  const [username, setUsername] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const scrollRef = useRef<ScrollView>(null);

  const topic = `${TOPIC_PREFIX}/${roomId}`;

  const { status, messages, sendMessage } = useMqtt({
    brokerUrl: BROKER_URL,
    topic,
    username: username ?? '__waiting__',
  });

  useEffect(() => {
    if (messages.length > 0) {
      scrollRef.current?.scrollToEnd({ animated: true });
    }
  }, [messages]);

  const handleSend = () => {
    if (!newMessage.trim() || !username) return;
    sendMessage(newMessage);
    setNewMessage('');
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);
  };

  return (
    <View style={{ flex: 1 }}>
      {!username && <AskUsernameModal onConfirm={(name) => setUsername(name)} />}

      <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.navigate('ChatRooms')}>
            <ArrowLeft size={20} color={colors.mutedForeground} />
          </TouchableOpacity>
          <Text style={styles.roomIcon}>{roomIcon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerTitle}>{roomName}</Text>
            <StatusBadge status={status} />
          </View>
        </View>

        <View style={styles.topicBar}>
          <Text style={styles.topicText}>📡 {topic}</Text>
        </View>

        <ScrollView
          ref={scrollRef}
          style={styles.messages}
          contentContainerStyle={styles.messagesInner}
          onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: true })}
        >
          {messages.length === 0 && status === 'connected' && (
            <View style={styles.emptyBox}>
              <Text style={styles.emptyText}>ยังไม่มีข้อความในห้องนี้{'\n'}เริ่มต้นพูดคุยเลย 👋</Text>
            </View>
          )}

          {messages.map((msg) => (
            <View key={msg.id} style={[styles.msgRow, msg.isOwn && styles.msgRowOwn]}>
              {!msg.isOwn && (
                <View style={[styles.avatar, { backgroundColor: msg.avatarColor }]}>
                  <Text style={styles.avatarText}>{msg.senderInitials}</Text>
                </View>
              )}
              <View style={[styles.msgContent, msg.isOwn && styles.msgContentOwn]}>
                {!msg.isOwn && <Text style={styles.msgSender}>{msg.sender}</Text>}
                <View style={[styles.bubble, msg.isOwn && styles.bubbleOwn]}>
                  <Text style={[styles.bubbleText, msg.isOwn && styles.bubbleTextOwn]}>{msg.content}</Text>
                  <Text style={[styles.bubbleTime, msg.isOwn && styles.bubbleTimeOwn]}>{msg.timestamp}</Text>
                </View>
              </View>
            </View>
          ))}
        </ScrollView>

        <View style={styles.inputBar}>
          <TextInput
            value={newMessage}
            onChangeText={setNewMessage}
            placeholder={username ? 'พิมพ์ข้อความ...' : 'กรุณาตั้งชื่อก่อน...'}
            placeholderTextColor={colors.mutedForeground}
            style={styles.input}
            multiline
            editable={!!username && status === 'connected'}
            blurOnSubmit={false}
          />
          <TouchableOpacity
            style={[styles.sendBtn, (!newMessage.trim() || !username || status !== 'connected') && styles.sendBtnDisabled]}
            onPress={handleSend}
            disabled={!newMessage.trim() || !username || status !== 'connected'}
          >
            <Send size={20} color={colors.white} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 24, paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.card, gap: 8 },
  roomIcon: { fontSize: 22 },
  headerTitle: { fontSize: 17, color: colors.foreground, fontFamily: fonts.medium },
  topicBar: { backgroundColor: colors.primary5, borderBottomWidth: 1, borderBottomColor: colors.primary20, paddingHorizontal: 20, paddingVertical: 6 },
  topicText: { fontSize: 11, color: colors.mutedForeground, fontFamily: fonts.regular },
  messages: { flex: 1 },
  messagesInner: { padding: 24, gap: 16, flexGrow: 1 },
  emptyBox: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 60 },
  emptyText: { fontSize: 14, color: colors.mutedForeground, fontFamily: fonts.regular, textAlign: 'center', lineHeight: 22 },
  msgRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  msgRowOwn: { flexDirection: 'row-reverse' },
  avatar: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  avatarText: { color: colors.white, fontSize: 13, fontFamily: fonts.medium },
  msgContent: { flex: 1, alignItems: 'flex-start' },
  msgContentOwn: { alignItems: 'flex-end' },
  msgSender: { fontSize: 12, color: colors.mutedForeground, fontFamily: fonts.regular, marginBottom: 4, marginLeft: 2 },
  bubble: { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: 16, paddingHorizontal: 16, paddingVertical: 10, maxWidth: '80%' },
  bubbleOwn: { backgroundColor: colors.primary, borderWidth: 0 },
  bubbleText: { fontSize: 15, color: colors.foreground, lineHeight: 22, fontFamily: fonts.regular },
  bubbleTextOwn: { color: colors.white },
  bubbleTime: { fontSize: 11, color: colors.mutedForeground, marginTop: 4, fontFamily: fonts.regular },
  bubbleTimeOwn: { color: 'rgba(255,255,255,0.7)' },
  inputBar: { flexDirection: 'row', alignItems: 'flex-end', gap: 12, paddingHorizontal: 24, paddingVertical: 16, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: colors.card },
  input: { flex: 1, minHeight: 48, maxHeight: 120, backgroundColor: colors.inputBackground, borderRadius: 16, paddingHorizontal: 16, paddingVertical: 10, fontSize: 15, color: colors.foreground, fontFamily: fonts.regular },
  sendBtn: { width: 48, height: 48, borderRadius: 24, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  sendBtnDisabled: { opacity: 0.5 },
});
